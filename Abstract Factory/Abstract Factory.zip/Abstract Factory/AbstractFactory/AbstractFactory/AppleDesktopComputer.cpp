#include "AppleDesktopComputer.h"
#include <iostream>

namespace appledesktop
{
	void AppleDesktopComputer::Create()
	{
		std::cout << "ƻ������" << std::endl;
	}
}