#pragma once
#include "DesktopComputer.h"

namespace appledesktop
{
	class AppleDesktopComputer :public desktop::DesktopComputer
	{
	public:
		void Create();
	};
}

