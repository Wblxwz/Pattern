#include "AppleIpad.h"
#include <iostream>

namespace appleipad
{
	void AppleIpad::Create()
	{
		std::cout << "ƻ��ƽ��" << std::endl;
	}
}