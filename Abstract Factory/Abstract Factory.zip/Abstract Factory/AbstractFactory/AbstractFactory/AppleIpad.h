#pragma once
#include "Ipad.h"

namespace appleipad
{
	class AppleIpad :public ipad::Ipad
	{
	public:
		void Create();
	};

}