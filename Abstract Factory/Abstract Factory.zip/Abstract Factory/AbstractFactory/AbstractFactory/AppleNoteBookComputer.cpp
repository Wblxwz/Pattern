#include "AppleNoteBookComputer.h"
#include <iostream>

namespace applenotebook
{
	void AppleNoteBookComputer::Create()
	{
		std::cout << "ƻ���ʼǱ�" << std::endl;
	}
}