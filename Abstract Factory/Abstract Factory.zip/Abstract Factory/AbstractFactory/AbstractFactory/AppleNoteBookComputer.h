#pragma once
#include "NoteBookComputer.h"

namespace applenotebook
{
	class AppleNoteBookComputer :public notebook::NoteBookComputer
	{
	public:
		void Create();
	};
}

