#include "ApplePhone.h"
#include <iostream>

namespace applephone
{
	void ApplePhone::Create()
	{
		std::cout << "ƻ���ֻ�" << std::endl;
	}
}