#pragma once
#include "Phone.h"

namespace applephone
{
	class ApplePhone :public phone::Phone
	{
	public:
		void Create();
	};
}