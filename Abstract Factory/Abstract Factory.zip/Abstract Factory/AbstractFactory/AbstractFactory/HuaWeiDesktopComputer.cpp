#include "HuaWeiDesktopComputer.h"
#include <iostream>

namespace huaweidesktop
{
	void HuaWeiDesktopComputer::Create()
	{
		std::cout << "��Ϊ����" << std::endl;
	}
}