#pragma once
#include "DesktopComputer.h"

namespace huaweidesktop
{
	class HuaWeiDesktopComputer :public desktop::DesktopComputer
	{
	public:
		void Create();
	};
}

