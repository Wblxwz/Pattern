#include "HuaWeiIpad.h"
#include <iostream>

namespace huaweiipad
{
	void HuaWeiIpad::Create()
	{
		std::cout << "��Ϊƽ��" << std::endl;
	}
}