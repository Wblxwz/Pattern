#pragma once
#include "Ipad.h"

namespace huaweiipad
{
	class HuaWeiIpad :public ipad::Ipad
	{
	public:
		void Create();
	};
}