#include "HuaWeiNoteBookComputer.h"
#include <iostream>

namespace huaweinotebook
{
	void HuaWeiNoteBookComputer::Create()
	{
		std::cout << "��Ϊ�ʼǱ�" << std::endl;
	}
}