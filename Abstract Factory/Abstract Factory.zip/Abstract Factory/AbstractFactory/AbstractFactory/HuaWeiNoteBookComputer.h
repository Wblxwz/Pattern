#pragma once
#include "NoteBookComputer.h"

namespace huaweinotebook
{
	class HuaWeiNoteBookComputer :public notebook::NoteBookComputer
	{
	public:
		void Create();
	};
}

