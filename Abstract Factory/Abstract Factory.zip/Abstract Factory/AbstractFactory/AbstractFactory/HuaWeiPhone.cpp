#include "HuaWeiPhone.h"
#include <iostream>

namespace huaweiphone
{
	void HuaWeiPhone::Create()
	{
		std::cout << "��Ϊ�ֻ�" << std::endl;
	}
}