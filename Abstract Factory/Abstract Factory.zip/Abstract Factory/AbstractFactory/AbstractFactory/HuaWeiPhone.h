#pragma once
#include "Phone.h"

namespace huaweiphone
{
	class HuaWeiPhone :public phone::Phone
	{
	public:
		void Create();
	};
}