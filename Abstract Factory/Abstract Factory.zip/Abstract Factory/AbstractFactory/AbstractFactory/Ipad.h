#pragma once

namespace ipad
{
	class Ipad
	{
	public:
		virtual void Create() = 0;
		virtual ~Ipad() = default;
	};
}