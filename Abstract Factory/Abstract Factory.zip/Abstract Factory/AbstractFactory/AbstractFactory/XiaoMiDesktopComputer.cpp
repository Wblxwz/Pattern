#include "XiaoMiDesktopComputer.h"
#include <iostream>

namespace xiaomidesktop
{
	void XiaoMiDesktopComputer::Create()
	{
		std::cout << "С�׵���" << std::endl;
	}
}