#pragma once
#include "DesktopComputer.h"

namespace xiaomidesktop
{
	class XiaoMiDesktopComputer :public desktop::DesktopComputer
	{
	public:
		void Create();
	};
}

