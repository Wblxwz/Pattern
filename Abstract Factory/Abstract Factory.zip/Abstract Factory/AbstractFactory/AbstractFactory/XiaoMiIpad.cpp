#include "XiaoMiIpad.h"
#include <iostream>

namespace xiaomiipad
{
	void XiaoMiIpad::Create()
	{
		std::cout << "С��ƽ��" << std::endl;
	}
}