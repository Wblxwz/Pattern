#pragma once
#include "Ipad.h"

namespace xiaomiipad
{
	class XiaoMiIpad :public ipad::Ipad
	{
	public:
		void Create();
	};
}