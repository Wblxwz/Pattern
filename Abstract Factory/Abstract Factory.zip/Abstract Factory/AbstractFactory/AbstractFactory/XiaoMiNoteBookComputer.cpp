#include "XiaoMiNoteBookComputer.h"
#include <iostream>

namespace xiaominotebook
{
	void XiaoMiNoteBookComputer::Create()
	{
		std::cout << "С�ױʼǱ�" << std::endl;
	}
}