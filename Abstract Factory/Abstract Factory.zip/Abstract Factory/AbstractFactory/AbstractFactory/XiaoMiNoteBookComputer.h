#pragma once
#include "NoteBookComputer.h"

namespace xiaominotebook
{
	class XiaoMiNoteBookComputer :public notebook::NoteBookComputer
	{
	public:
		void Create();
	};
}

