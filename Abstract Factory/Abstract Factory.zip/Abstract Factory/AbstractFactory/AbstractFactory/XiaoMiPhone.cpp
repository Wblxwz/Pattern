#include "XiaoMiPhone.h"
#include <iostream>

namespace xiaomiphone
{
	void XiaoMiPhone::Create()
	{
		std::cout << "С���ֻ�" << std::endl;
	}
}