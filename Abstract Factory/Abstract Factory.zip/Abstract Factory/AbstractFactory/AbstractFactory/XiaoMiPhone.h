#pragma once
#include "Phone.h"

namespace xiaomiphone
{
	class XiaoMiPhone :public phone::Phone
	{
	public:
		void Create();
	};
}